/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package sebas.lab.testing;

/**
 *
 * @author jacks
 */
public interface UserRepository {

    User findById(String id);
}
